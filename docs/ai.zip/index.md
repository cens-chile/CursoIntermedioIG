# Home - Este es el título de la guía en | R4 v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://example.org/curso/ImplementationGuide/fhir.example.curso | *Version*:0.1.0 |
| Draft as of 2025-10-22 | *Computable Name*:CursoIG |

# CursoIG — Guía de Implementación del curso intermedio

Bienvenido a la fuente de la Implementation Guide (IG) usada en este curso. Este repositorio contiene definiciones en FHIR Shorthand (FSH), páginas y los artefactos generados que la HL7 IG Publisher usa para publicar el sitio.

Flujo breve:

1. Edita`input/fsh/*.fsh`para añadir perfiles, extensiones e instancias.
1. Ejecuta`sushi -o fsh-generated`para compilar FSH → FHIR JSON/XML.
1. Ejecuta`./_genonce.sh`(usa`input-cache/publisher.jar`) para generar HTML.

Ubicaciones clave:

* `sushi-config.yaml` configura id, canonical, fhirVersion y el menú de páginas.
* `ig.ini` apunta a `fsh-generated/resources/ImplementationGuide-*.json`.
* `input/pagecontent/` contiene `.md` y `.xml` que aparecen en la web.

Consejos prácticos:

* Si falta `publisher.jar`, corre `./_updatePublisher.sh` para descargarlo.
* `_genonce.sh` detecta `tx.fhir.org` y pasará `-tx n/a` cuando esté offline.
* Asegura Java 8+ en PATH; `_genonce.sh` llama a `java -jar`.

¿Qué aprenderás aquí?

* Cómo escribir FSH simple (ej.: `input/fsh/patient.fsh`) y generar artefactos.
* Cómo mapear páginas con `sushi-config.yaml: menu:` → `input/pagecontent/`.
* Cómo publicar localmente con la IG Publisher y entender opciones de tx. Pide un flujo CI o ejemplos adicionales y los añadiré al índice.

## Dependency Table






## Tabla de Metadata

| | |
| :--- | :--- |
| Name | Value |
| path | [http://hl7.org/fhir/R4/](http://hl7.org/fhir/R4/) |
| [canonical](canonical) | [http://example.org/curso](http://example.org/curso) |
| igId | [Este es el título de la guía en | R4](fhir.example.curso) |
| igName | CursoIG |
| packageId | [Este es el título de la guía en | R4](fhir.example.curso) |
| igVer | 0.1.0 |
| errorCount | 1 |
| version | 4.0.1 |
| releaseLabel | ci-build |
| revision | a53ec6ee1b |
| versionFull | 4.0.1-a53ec6ee1b |
| toolingVersion | 5.0.0 |
| toolingRevision | 3 |
| toolingVersionFull | 5.0.0 (3) |
| genDate | Wed, Oct 22, 2025 17:39-0300 |
| genDay | 22/10/2025 |
| gitstatus | main |

